export GOPATH=~/goBook
export go=/usr/local/go
export GRADLE_HOME=/home/khine_htun/gradle-7.2
export CLICOLOR=1
export JAVA_HOME=/home/khine_htun/jdk/jdk1.8.0_281
export MVN_HOME=/home/khine_htun/maven/apache-maven-3.6.3
export GO_HOME=/usr/local/go
export NODE_HOME=/home/khine_htun/node/node-v14.16.0-linux-x64
export LDFLAGS="-L/usr/local/opt/openssl/lib"
export CPPFLAGS="-I/usr/local/opt/openssl/include"
#export mule.home=/Users/khine.htun/AnypointStudio/studio-workspace
export MULE_HOME=/home/khine/mule/mule-enterprise-standalone-4.2.2-hf1
export PYCURL_SSL_LIBRARY=openssl
export PATH=$PATH:~/bin:$JAVA_HOME/bin:$MVN_HOME/bin:$GO_HOME/bin:$NODE_HOME/bin:$HOME/.local/bin:.:$GRADLE_HOME/bin:
export NVM_DIR="$HOME/.config/nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion

############################################################
# Update the following to personalize your bash_profile
# this file will be automatically be sourced via /home/khine_htun/.bash_profile

## GPG Email
#The email address associated with your GPG key
export CORP_GPGKEY_ADDRESS="khine.htun@aurora.tech"

export INITIALS="KHI"

#Folder path to where you will be checking out git projects
export CORP_HOME="${HOME}/src"

#Folder path for shared onboarding docs
export CORP_ONBOARD="/mnt/chromeos/GoogleDrive/MyDrive/"

export CORP_USERNAME=${USER}

export KEY_SUFFIX="aurora.tech"
export GIT_ORG="[GITORG]"

# Set architecture flags for Ruby RVM to play nice
export ARCHFLAGS="-arch x86_64"

##########################################################

## Feel free to add your own shell customizations here

export SLACK_BOT_TOKEN=xoxb-615522798199-1915630137184-Za3lUWSpAJCW66RDjNnAu4yp
export SLACK_SIGNING_SECRET=5439abf02f86d44769dc0cd98a0fcf53
export tfvdesk=/home/khine_htun/src/av/cloud/terraform_aws/accounts/vdesk-dev/app
export lambdavdesk=/home/khine_htun/src/av/cloud/terraform_aws/modules/lambda
export pyvdesk=/home/khine_htun/src/av/it/lambdas/vdesk
