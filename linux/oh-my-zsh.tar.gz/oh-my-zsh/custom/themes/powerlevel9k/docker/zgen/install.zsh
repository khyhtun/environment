#!/bin/zsh

git clone https://github.com/tarjoilija/zgen.git "${HOME}/.zgen"

# EOF
