# GraphQL Samples

These sample files are borrowed from Facebook's [graphql-js][] project.

[graphql-js]: https://github.com/graphql/graphql-js
