const a: () => number = () => { return 2; };
