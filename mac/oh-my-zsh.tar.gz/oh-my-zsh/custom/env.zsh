export python=/Users/khyhtun/Library/Python/2.7
export java_home=/Library/Java/JavaVirtualMachines/jdk1.8.0_251.jdk/Contents/Home
export maven_home=/Users/khyhtun/maven/apache-maven-3.6.3
export PATH=$PATH:$java_home/bin:$maven_home/bin:~/bin:$python/bin:
export podcast=/Users/khyhtun/Library/Group\ Containers/243LU875E5.groups.com.apple.podcasts/Library/Cache
export SLACK_BOT_TOKEN=xoxb-615522798199-1915630137184-Za3lUWSpAJCW66RDjNnAu4yp
export SLACK_SIGNING_SECRET=5439abf02f86d44769dc0cd98a0fcf53
