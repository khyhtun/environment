# Abstract for [Vim](http://vim.org)

> A dark theme for [Vim](http://vim.org) based on [Abstract](https://www.abstractapp.com/).

![Screenshot](https://s-media-cache-ak0.pinimg.com/originals/65/3d/7d/653d7d6b710bbbfdab435d7169f99e88.jpg)

## Team

This theme is maintained by [Jonathan Simcoe](http://jdsimcoe.com).

## License

[MIT License](./LICENSE)
